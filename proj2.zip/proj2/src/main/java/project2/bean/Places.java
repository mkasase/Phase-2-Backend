package project2.bean;


import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Entity
public class Places {
	@Id
	private int pid;
	private String source;
	private String destination;
	
	@OneToMany
	@JoinColumn(name ="pid")
	private List<Flight> listofFlights;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public List<Flight> getListofFlights() {
		return listofFlights;
	}
	public void setListofFlights(List<Flight> listofFlights) {
		this.listofFlights = listofFlights;
	}
	
	@Override
	public String toString() {
		return "Places [pid=" + pid + ", source=" + source + ", destination=" + destination + ", listofFlights="
				+ listofFlights + "]";
	}
	

}
