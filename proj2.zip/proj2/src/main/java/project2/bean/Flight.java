package project2.bean;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Flight {
	
	@Id
	private int fid;
	private String FlightName;
	private float price;
	private LocalDate departure;
	private int seats;
	private int pid;
	public int getfid() {
		return fid;
	}
	public void setfid(int fid) {
		this.fid = fid;
	}
	public String getFlightName() {
		return FlightName;
	}
	public void setFlightName(String flightName) {
		FlightName = flightName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public LocalDate getdeparture() {
		return departure;
	}
	public void setdeparture(LocalDate departure) {
		this.departure = departure;
	}
	
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	
	@Override
	public String toString() {
		return "Flight [fid=" + fid + ", FlightName=" + FlightName + ", price=" + price + ", departure="
				+ departure + ", seats=" + seats + ", pid=" + pid + "]";
	}
	


}
